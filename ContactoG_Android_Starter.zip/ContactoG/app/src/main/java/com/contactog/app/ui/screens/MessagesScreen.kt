package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun MessagesScreen(onBack: () -> Unit) {
    val chats = listOf(
        "Alex R. — ¡Qué bueno verte por aquí! 💙",
        "Luis Torres — Nos vemos en la próxima reunión.",
        "Comunidad Viajes — Tienes un nuevo mensaje.",
        "Carlos M. — Jajaja, obvio 😄"
    )

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Inicio") }
        Text("Mensajes", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        chats.forEach {
            ListItem(
                headlineContent = { Text(it.substringBefore(" — ")) },
                supportingContent = { Text(it.substringAfter(" — ")) }
            )
            HorizontalDivider()
        }
    }
}
