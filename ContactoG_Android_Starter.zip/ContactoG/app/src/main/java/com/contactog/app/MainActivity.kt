package com.contactog.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.contactog.app.ui.ContactoGApp
import com.contactog.app.ui.theme.ContactoGTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ContactoGTheme {
                ContactoGApp()
            }
        }
    }
}
