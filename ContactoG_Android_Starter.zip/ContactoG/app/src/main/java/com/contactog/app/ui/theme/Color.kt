package com.contactog.app.ui.theme

import androidx.compose.ui.graphics.Color

val ContactoBackground = Color(0xFF071018)
val ContactoSurface = Color(0xFF0E1B24)
val ContactoCard = Color(0xFF12232D)
val ContactoPetrol = Color(0xFF087E8B)
val ContactoTurquoise = Color(0xFF22C7C9)
val ContactoText = Color(0xFFFFFFFF)
val ContactoSecondaryText = Color(0xFFA7B5BD)
