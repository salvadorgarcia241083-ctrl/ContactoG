package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ProfileScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Inicio") }
        Text("Mi perfil", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        Text("Diego_23", style = MaterialTheme.typography.titleLarge)
        Text("@diego_23")
        Spacer(Modifier.height(12.dp))
        Text("Amante de la música, los viajes y conocer gente nueva. 🌈")
        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("312\nPublicaciones")
            Text("1.4K\nSeguidores")
            Text("892\nSiguiendo")
        }

        Spacer(Modifier.height(24.dp))
        OutlinedButton(
            onClick = {},
            modifier = Modifier.fillMaxWidth()
        ) { Text("Editar perfil") }
    }
}
