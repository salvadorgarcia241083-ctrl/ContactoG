package com.contactog.app.ui.navigation

import androidx.compose.runtime.*
import com.contactog.app.ui.screens.*

@Composable
fun ContactoGNavHost(startRoute: String) {
    var currentRoute by remember { mutableStateOf(startRoute) }

    when (currentRoute) {
        Route.Welcome.route -> WelcomeScreen(
            onCreateAccount = { currentRoute = Route.Register.route },
            onLogin = { currentRoute = Route.Home.route }
        )
        Route.Register.route -> RegisterScreen(
            onRegistered = { currentRoute = Route.Home.route }
        )
        Route.Home.route -> HomeScreen(
            onCommunities = { currentRoute = Route.Communities.route },
            onCreatePost = { currentRoute = Route.CreatePost.route },
            onMessages = { currentRoute = Route.Messages.route },
            onProfile = { currentRoute = Route.Profile.route }
        )
        Route.Communities.route -> CommunitiesScreen(
            onBack = { currentRoute = Route.Home.route }
        )
        Route.CreatePost.route -> CreatePostScreen(
            onBack = { currentRoute = Route.Home.route },
            onPublished = { currentRoute = Route.Home.route }
        )
        Route.Messages.route -> MessagesScreen(
            onBack = { currentRoute = Route.Home.route }
        )
        Route.Profile.route -> ProfileScreen(
            onBack = { currentRoute = Route.Home.route }
        )
    }
}
