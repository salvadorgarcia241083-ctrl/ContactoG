package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CreatePostScreen(
    onBack: () -> Unit,
    onPublished: () -> Unit
) {
    var text by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Volver") }
        Text("Crear publicación", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = text,
            onValueChange = { if (it.length <= 500) text = it },
            label = { Text("¿Qué quieres compartir hoy?") },
            modifier = Modifier.fillMaxWidth().height(180.dp)
        )

        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {}) { Text("📷 Foto") }
            OutlinedButton(onClick = {}) { Text("🎥 Video") }
            OutlinedButton(onClick = {}) { Text("📊 Encuesta") }
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = onPublished,
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Publicar") }
    }
}
