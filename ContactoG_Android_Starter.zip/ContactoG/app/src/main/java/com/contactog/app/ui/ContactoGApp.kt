package com.contactog.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.contactog.app.ui.navigation.ContactoGNavHost
import com.contactog.app.ui.navigation.Route

@Composable
fun ContactoGApp() {
    var startRoute by remember { mutableStateOf(Route.Welcome.route) }

    Surface(modifier = Modifier.fillMaxSize()) {
        ContactoGNavHost(startRoute = startRoute)
    }
}
