package com.contactog.app.ui.navigation

sealed class Route(val route: String) {
    data object Welcome : Route("welcome")
    data object Register : Route("register")
    data object Home : Route("home")
    data object Communities : Route("communities")
    data object CreatePost : Route("create_post")
    data object Messages : Route("messages")
    data object Profile : Route("profile")
}
