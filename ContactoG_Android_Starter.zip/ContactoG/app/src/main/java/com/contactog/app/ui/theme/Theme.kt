package com.contactog.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ContactoColors = darkColorScheme(
    primary = ContactoTurquoise,
    secondary = ContactoPetrol,
    background = ContactoBackground,
    surface = ContactoSurface,
    surfaceVariant = ContactoCard,
    onPrimary = ContactoBackground,
    onBackground = ContactoText,
    onSurface = ContactoText
)

@Composable
fun ContactoGTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ContactoColors,
        content = content
    )
}
