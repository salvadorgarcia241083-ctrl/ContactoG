package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    onCommunities: () -> Unit,
    onCreatePost: () -> Unit,
    onMessages: () -> Unit,
    onProfile: () -> Unit
) {
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = true,
                    onClick = {},
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Inicio") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onCommunities,
                    icon = { Icon(Icons.Default.Groups, null) },
                    label = { Text("Comunidad") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onCreatePost,
                    icon = { Icon(Icons.Default.AddCircle, null) },
                    label = { Text("Crear") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onMessages,
                    icon = { Icon(Icons.Default.Chat, null) },
                    label = { Text("Mensajes") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onProfile,
                    icon = { Icon(Icons.Default.Person, null) },
                    label = { Text("Perfil") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)
        ) {
            Text("Contacto G", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(8.dp))
            Text(
                "Tu comunidad, tus historias, tu espacio.",
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.height(20.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("¿Qué quieres compartir hoy?")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onCreatePost) {
                        Text("Crear publicación")
                    }
                }
            }

            Spacer(Modifier.height(20.dp))

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Diego_23", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Hoy fue un gran día. La vida es mejor cuando te rodeas de gente que te hace sentir bien. 🌈")
                    Spacer(Modifier.height(12.dp))
                    Text("♡ 128     💬 24     ↗ Compartir")
                }
            }
        }
    }
}
