package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CommunitiesScreen(onBack: () -> Unit) {
    val communities = listOf(
        "Orgullo y Diversidad",
        "Música y Arte",
        "Viajes",
        "Deportes y Bienestar",
        "Videojuegos",
        "Cine y Series"
    )

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Inicio") }
        Text("Comunidades", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        communities.forEach {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(it)
                    TextButton(onClick = {}) { Text("Unirme") }
                }
            }
        }
    }
}
