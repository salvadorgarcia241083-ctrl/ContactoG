package com.contactog.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun WelcomeScreen(
    onCreateAccount: () -> Unit,
    onLogin: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("💬", style = MaterialTheme.typography.displayLarge)
        Spacer(Modifier.height(12.dp))
        Text("Contacto G", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "Tu comunidad, tus historias, tu espacio.",
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(36.dp))
        Button(
            onClick = onCreateAccount,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Crear cuenta") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Iniciar sesión") }
    }
}
