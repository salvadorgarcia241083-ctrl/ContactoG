# Contacto G 1.0

Aplicación Android de comunidad y convivencia para hombres gay.

## Identidad visual
- Fondo: #071018
- Azul petróleo: #087E8B
- Turquesa: #22C7C9
- Texto: #FFFFFF
- Tipografía conceptual: Inter
- Logo: G en forma de burbuja de conversación

## Estructura actual
- Bienvenida
- Registro
- Inicio / Feed
- Comunidades
- Crear publicación
- Mensajes
- Perfil

## Próximas fases
1. Backend y autenticación real
2. Base de datos de usuarios
3. Publicaciones con imágenes
4. Comentarios y reacciones
5. Seguidores
6. Comunidades reales
7. Chat en tiempo real
8. Notificaciones
9. Reportes, bloqueo y moderación
10. Preparación para Google Play

## Abrir el proyecto
Abrir la carpeta `ContactoG` en Android Studio y sincronizar Gradle.
